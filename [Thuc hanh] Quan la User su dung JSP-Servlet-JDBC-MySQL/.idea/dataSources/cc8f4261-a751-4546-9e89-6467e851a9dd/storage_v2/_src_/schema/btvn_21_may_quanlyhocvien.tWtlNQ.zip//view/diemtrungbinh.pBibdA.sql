create definer = root@localhost view diemtrungbinh as
select `co`.`idCourse` AS `idCourse`, `co`.`nameCourse` AS `nameCourse`, avg(`p`.`point`) AS `DTB`
from (`btvn_21_may_quanlyhocvien`.`course` `co`
         join `btvn_21_may_quanlyhocvien`.`point` `p` on ((`co`.`idCourse` = `p`.`idCourse`)))
group by `co`.`idCourse`;

