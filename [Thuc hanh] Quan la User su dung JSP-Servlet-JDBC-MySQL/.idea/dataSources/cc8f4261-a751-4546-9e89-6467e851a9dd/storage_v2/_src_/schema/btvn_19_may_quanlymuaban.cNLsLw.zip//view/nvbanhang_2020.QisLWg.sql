create definer = root@localhost view nvbanhang_2020 as
select `nv`.`Ten` AS `Ten`, `ddh`.`MaNhanVien` AS `MaNhanVien`
from (`btvn_19_may_quanlymuaban`.`nhanvien` `nv`
         join `btvn_19_may_quanlymuaban`.`dondathang` `ddh` on ((`nv`.`MaNhanVien` = `ddh`.`MaNhanVien`)))
where (year(`ddh`.`NgayChuyenHang`) = '2020');

