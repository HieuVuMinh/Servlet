create definer = root@localhost view countmnv as
select `btvn_19_may_quanlymuaban`.`nvbanhang_2020`.`MaNhanVien`        AS `MaNhanVien`,
       `btvn_19_may_quanlymuaban`.`nvbanhang_2020`.`Ten`               AS `Ten`,
       count(`btvn_19_may_quanlymuaban`.`nvbanhang_2020`.`MaNhanVien`) AS `count`
from `btvn_19_may_quanlymuaban`.`nvbanhang_2020`
group by `btvn_19_may_quanlymuaban`.`nvbanhang_2020`.`MaNhanVien`;

