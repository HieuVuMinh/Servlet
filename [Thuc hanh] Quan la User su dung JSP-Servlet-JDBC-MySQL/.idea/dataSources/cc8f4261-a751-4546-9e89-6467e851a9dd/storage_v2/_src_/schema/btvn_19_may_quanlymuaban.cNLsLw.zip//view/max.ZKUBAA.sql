create definer = root@localhost view max as
select `btvn_19_may_quanlymuaban`.`countmnv`.`MaNhanVien` AS `MaNhanVien`,
       `btvn_19_may_quanlymuaban`.`countmnv`.`Ten`        AS `Ten`,
       max(`btvn_19_may_quanlymuaban`.`countmnv`.`count`) AS `max(count)`
from `btvn_19_may_quanlymuaban`.`countmnv`;

