create definer = root@localhost view vw_ctpxuat_vt_px as
select `btvn_24_may_quanlyvattu`.`chitietphieuxuat`.`PhieuXuatId`       AS `PhieuXuatId`,
       `p`.`TenKhachHang`                                               AS `TenKhachHang`,
       `v`.`VatTuId`                                                    AS `VatTuId`,
       `v`.`TenVatTu`                                                   AS `TenVatTu`,
       `btvn_24_may_quanlyvattu`.`chitietphieuxuat`.`SoLuongXuat`       AS `SoLuongXuat`,
       `btvn_24_may_quanlyvattu`.`chitietphieuxuat`.`DonGiaXuat`        AS `DonGiaXuat`,
       sum((`btvn_24_may_quanlyvattu`.`chitietphieuxuat`.`SoLuongXuat` *
            `btvn_24_may_quanlyvattu`.`chitietphieuxuat`.`DonGiaXuat`)) AS `Thanh Tien Xuat`
from ((`btvn_24_may_quanlyvattu`.`chitietphieuxuat` join `btvn_24_may_quanlyvattu`.`vattu` `v` on ((`btvn_24_may_quanlyvattu`.`chitietphieuxuat`.`VatTuId` = `v`.`VatTuId`)))
         join `btvn_24_may_quanlyvattu`.`phieuxuat` `p`
              on ((`btvn_24_may_quanlyvattu`.`chitietphieuxuat`.`PhieuXuatId` = `p`.`PhieuXuatId`)))
group by `v`.`VatTuId`, `btvn_24_may_quanlyvattu`.`chitietphieuxuat`.`PhieuXuatId`,
         `btvn_24_may_quanlyvattu`.`chitietphieuxuat`.`SoLuongXuat`,
         `btvn_24_may_quanlyvattu`.`chitietphieuxuat`.`DonGiaXuat`
order by `btvn_24_may_quanlyvattu`.`chitietphieuxuat`.`PhieuXuatId`;

