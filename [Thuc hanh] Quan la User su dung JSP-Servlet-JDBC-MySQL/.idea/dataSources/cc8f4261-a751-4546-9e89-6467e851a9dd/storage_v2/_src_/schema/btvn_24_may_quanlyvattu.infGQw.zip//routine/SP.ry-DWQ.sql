create
    definer = root@localhost procedure SP(IN Ma varchar(50))
begin
    if (exists(select MaVatTu from vattu where MaVatTu = Ma))
    then
    select VT.MaVatTu, sum((T.SoLuongDau + T.TongSoLuongNhap) - T.TongSoLuongXuat)
        as 'Tong So Luong Cuoi'
        from vattu VT join TonKho T on VT.VatTuId = T.VatTuId
    where VT.MaVatTu = (select MaVatTu from vattu where MaVatTu = Ma)
    group by VT.MaVatTu;
    else
        select concat('Không tìm thấy vật tư có mã vật tư là', Ma) as Message;
    end if;
end;

