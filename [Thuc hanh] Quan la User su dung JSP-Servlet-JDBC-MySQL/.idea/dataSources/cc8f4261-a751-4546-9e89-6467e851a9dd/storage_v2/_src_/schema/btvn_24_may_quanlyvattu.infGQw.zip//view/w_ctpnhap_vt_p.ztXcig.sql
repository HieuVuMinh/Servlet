create definer = root@localhost view w_ctpnhap_vt_p as
select `ctpn`.`PhieuNhapId`                              AS `PhieuNhapId`,
       `pn`.`NgayNhap`                                   AS `NgayNhap`,
       `pn`.`DonDatHangId`                               AS `DonDatHangId`,
       `vt`.`MaVatTu`                                    AS `MaVatTu`,
       `vt`.`TenVatTu`                                   AS `TenVatTu`,
       `ctpn`.`SoLuongNhap`                              AS `SoLuongNhap`,
       `ctpn`.`DonGiaNhap`                               AS `DonGiaNhap`,
       sum((`ctpn`.`SoLuongNhap` * `ctpn`.`DonGiaNhap`)) AS `Thanh Tien`
from ((`btvn_24_may_quanlyvattu`.`chitietphieunhap` `ctpn` join `btvn_24_may_quanlyvattu`.`vattu` `vt` on ((`vt`.`VatTuId` = `ctpn`.`VatTuId`)))
         join `btvn_24_may_quanlyvattu`.`phieunhap` `pn` on ((`pn`.`PhieuNhapId` = `ctpn`.`PhieuNhapId`)))
group by `vt`.`MaVatTu`, `pn`.`NgayNhap`, `pn`.`DonDatHangId`, `ctpn`.`PhieuNhapId`, `vt`.`TenVatTu`,
         `ctpn`.`SoLuongNhap`, `ctpn`.`DonGiaNhap`;

