create definer = root@localhost view w_ctpnhap_vt_pn_d as
select `ctpn`.`PhieuNhapId`                              AS `PhieuNhapId`,
       `pn`.`NgayNhap`                                   AS `NgayNhap`,
       `pn`.`DonDatHangId`                               AS `DonDatHangId`,
       `n`.`MaNhaCungCap`                                AS `MaNhaCungCap`,
       `vt`.`MaVatTu`                                    AS `MaVatTu`,
       `vt`.`TenVatTu`                                   AS `TenVatTu`,
       `ctpn`.`SoLuongNhap`                              AS `SoLuongNhap`,
       `ctpn`.`DonGiaNhap`                               AS `DonGiaNhap`,
       sum((`ctpn`.`SoLuongNhap` * `ctpn`.`DonGiaNhap`)) AS `Thanh Tien`
from ((((`btvn_24_may_quanlyvattu`.`phieunhap` `pn` join `btvn_24_may_quanlyvattu`.`chitietphieunhap` `ctpn` on ((`pn`.`PhieuNhapId` = `ctpn`.`PhieuNhapId`))) join `btvn_24_may_quanlyvattu`.`vattu` `vt` on ((`vt`.`VatTuId` = `ctpn`.`VatTuId`))) join `btvn_24_may_quanlyvattu`.`dondathang` `ddh` on ((`ddh`.`DonDatHangId` = `pn`.`DonDatHangId`)))
         join `btvn_24_may_quanlyvattu`.`nhacungcap` `n` on ((`ddh`.`NhaCungCapId` = `n`.`NhaCungCapId`)))
group by `vt`.`MaVatTu`, `pn`.`NgayNhap`, `pn`.`DonDatHangId`, `n`.`MaNhaCungCap`, `ctpn`.`PhieuNhapId`,
         `vt`.`TenVatTu`, `ctpn`.`SoLuongNhap`, `ctpn`.`DonGiaNhap`;

