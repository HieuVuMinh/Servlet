create definer = root@localhost view vw_ctpnhap_vt as
select `btvn_24_may_quanlyvattu`.`chitietphieunhap`.`PhieuNhapId`       AS `PhieuNhapId`,
       `vt`.`VatTuId`                                                   AS `VatTuId`,
       `vt`.`TenVatTu`                                                  AS `TenVatTu`,
       `btvn_24_may_quanlyvattu`.`chitietphieunhap`.`SoLuongNhap`       AS `SoLuongNhap`,
       `btvn_24_may_quanlyvattu`.`chitietphieunhap`.`DonGiaNhap`        AS `DonGiaNhap`,
       sum((`btvn_24_may_quanlyvattu`.`chitietphieunhap`.`SoLuongNhap` *
            `btvn_24_may_quanlyvattu`.`chitietphieunhap`.`DonGiaNhap`)) AS `Thanh Tien`
from (`btvn_24_may_quanlyvattu`.`chitietphieunhap`
         join `btvn_24_may_quanlyvattu`.`vattu` `vt`
              on ((`vt`.`VatTuId` = `btvn_24_may_quanlyvattu`.`chitietphieunhap`.`VatTuId`)))
group by `vt`.`VatTuId`, `btvn_24_may_quanlyvattu`.`chitietphieunhap`.`PhieuNhapId`, `vt`.`TenVatTu`,
         `btvn_24_may_quanlyvattu`.`chitietphieunhap`.`SoLuongNhap`,
         `btvn_24_may_quanlyvattu`.`chitietphieunhap`.`DonGiaNhap`;

