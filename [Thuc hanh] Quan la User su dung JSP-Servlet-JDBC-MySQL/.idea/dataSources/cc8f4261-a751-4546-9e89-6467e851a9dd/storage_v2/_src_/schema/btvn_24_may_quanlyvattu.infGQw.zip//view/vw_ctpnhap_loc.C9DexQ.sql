create definer = root@localhost view vw_ctpnhap_loc as
select `btvn_24_may_quanlyvattu`.`vw_ctpnhap`.`PhieuNhapId` AS `PhieuNhapId`,
       `btvn_24_may_quanlyvattu`.`vw_ctpnhap`.`VatTuId`     AS `VatTuId`,
       `btvn_24_may_quanlyvattu`.`vw_ctpnhap`.`SoLuongNhap` AS `SoLuongNhap`,
       `btvn_24_may_quanlyvattu`.`vw_ctpnhap`.`DonGiaNhap`  AS `DonGiaNhap`,
       `btvn_24_may_quanlyvattu`.`vw_ctpnhap`.`Thanh Tien`  AS `Thanh Tien`
from `btvn_24_may_quanlyvattu`.`vw_ctpnhap`
where (`btvn_24_may_quanlyvattu`.`vw_ctpnhap`.`SoLuongNhap` > 70);

