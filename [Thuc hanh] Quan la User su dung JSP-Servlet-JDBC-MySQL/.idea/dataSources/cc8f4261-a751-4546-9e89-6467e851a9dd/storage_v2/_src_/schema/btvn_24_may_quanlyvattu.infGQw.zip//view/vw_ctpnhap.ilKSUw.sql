create definer = root@localhost view vw_ctpnhap as
select `btvn_24_may_quanlyvattu`.`chitietphieunhap`.`PhieuNhapId`       AS `PhieuNhapId`,
       `btvn_24_may_quanlyvattu`.`chitietphieunhap`.`VatTuId`           AS `VatTuId`,
       `btvn_24_may_quanlyvattu`.`chitietphieunhap`.`SoLuongNhap`       AS `SoLuongNhap`,
       `btvn_24_may_quanlyvattu`.`chitietphieunhap`.`DonGiaNhap`        AS `DonGiaNhap`,
       sum((`btvn_24_may_quanlyvattu`.`chitietphieunhap`.`SoLuongNhap` *
            `btvn_24_may_quanlyvattu`.`chitietphieunhap`.`DonGiaNhap`)) AS `Thanh Tien`
from `btvn_24_may_quanlyvattu`.`chitietphieunhap`
group by `btvn_24_may_quanlyvattu`.`chitietphieunhap`.`VatTuId`,
         `btvn_24_may_quanlyvattu`.`chitietphieunhap`.`PhieuNhapId`,
         `btvn_24_may_quanlyvattu`.`chitietphieunhap`.`SoLuongNhap`,
         `btvn_24_may_quanlyvattu`.`chitietphieunhap`.`DonGiaNhap`;

