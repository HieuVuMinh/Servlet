create definer = root@localhost view maxcredit as
select max(`btvn_19_may_quanlytruonghoc`.`subject`.`Credit`) AS `max`
from `btvn_19_may_quanlytruonghoc`.`subject`;

