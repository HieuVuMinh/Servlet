create definer = root@localhost view avgofstudent as
select `s`.`StudentID`   AS `StudentID`,
       `s`.`StudentName` AS `StudentName`,
       `s`.`Address`     AS `Address`,
       `s`.`Phone`       AS `Phone`,
       `s`.`ClassID`     AS `ClassID`,
       avg(`m`.`Mark`)   AS `DiemTrungBinh`
from (`btvn_19_may_quanlytruonghoc`.`student` `s`
         join `btvn_19_may_quanlytruonghoc`.`mark` `m` on ((`s`.`StudentID` = `m`.`StudentID`)))
group by `s`.`StudentName`;

