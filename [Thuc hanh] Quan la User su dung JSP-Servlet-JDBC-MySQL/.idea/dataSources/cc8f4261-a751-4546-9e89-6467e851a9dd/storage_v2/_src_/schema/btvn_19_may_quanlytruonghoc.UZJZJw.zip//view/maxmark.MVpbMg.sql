create definer = root@localhost view maxmark as
select max(`btvn_19_may_quanlytruonghoc`.`mark`.`Mark`) AS `max(Mark)`
from `btvn_19_may_quanlytruonghoc`.`mark`;

